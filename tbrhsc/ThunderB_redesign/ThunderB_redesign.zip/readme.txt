Thunder Bay Regional Health Science Centre website re-design
http://tbrhsc.wikiplay.ca/
------------------------------------------------------------------------

------------------------------------------------------------------------

.:: INTRODUCTION ::.

This is a project by Team 5 "Peregrine", a redesign of the original TBRHSC website located at tbrhsc.net

.:: AUTHORS ::.

Irina Le Coche
Diana Sevillano
Wilston D'Souza
Sandeep Kaur
Craig Veenstra


.:: FEATURES ::.
Please see requirements document for the full list of features and their description


.:: LOGINS AND PASSWORDS ::.

Admin (Staff login):
Username: username
Password: password
----------------
Doctors:
User name: cveenstra
Password: cveenstra

User name: lecoche
Password: lecoche
-------------------
Volunteer:
User name: volunteer
Password: volunteer

